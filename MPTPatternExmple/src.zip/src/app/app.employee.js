"use strict";
var Employee = (function () {
    function Employee() {
    }
    return Employee;
}());
exports.Employee = Employee;
//# sourceMappingURL=app.employee.js.map