import { Component } from '@angular/core';
import {Employee} from './app.employee';

@Component({
  selector: 'emp-component',
  templateUrl: './app.employeecomponent.html'
})


export class AppEmployeeComponent  
{ 
	 id:number;
	 name:string;
	salary:number;
	dept:string;
	id2:number;
	name2:string;
	salary2:number;
	dept2:string;
	
	emp:Employee[]=[];

	addData():void
	{
		if(this.id!=null&&this.name!=null&&this.salary!=0&&this.dept!=null)
		{
				let employee:Employee={empId:this.id,empName:this.name,empSalary:this.salary,empDept:this.dept};
				this.emp.push(employee);
		}
		else
		{
			alert("insert data");
		}
	}
	
	putData( id:number, name:string, salary:number,dept:string):void
	{
		
		this.id2=id;
		this.name2=name;
		this.salary2=salary;
		this.dept2=dept;
	}
	
	updateData():void
	{
		let employee:Employee={empId:this.id2,empName:this.name2,empSalary:this.salary2,empDept:this.dept2};
		this.emp.push(employee);
	}
	
}
